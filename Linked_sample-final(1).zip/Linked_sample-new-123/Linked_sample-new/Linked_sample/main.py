from flask import Flask, render_template, flash, redirect, url_for, session, request, logging, make_response, jsonify
import json
import random
import os
app = Flask(__name__)

statels = 'LIVE'
qtydls = '0'
global qtyols,sidels,symbol,client,size,orderidls,price_instr,exchange,dates
producttypels = 'STOCK'
askls  = '1.2'
bidls = '1.25'
ltpls = '1.2'
newls = []
fill_ls = []
price = '1.45'


@app.route('/',methods = ['GET', 'POST'])
def index():
	count = 0
	if request.method == 'POST':
		sidels = 'B'
		commonls = []
		symbol = request.form['symbol']
		symdescr = request.form['symdescr']
		size = request.form['size']
		qtyols = size
		orderidls = random.randint(100000,10000000)
		price_instr = request.form['price_instr']
		limit = request.form['limit']
		client = request.form['client']
		client_descr = request.form['client_descr']
		exchange = request.form['exchange']
		account  = request.form['account']
		counter_party = request.form['counter_party']
		day_order = request.form['day_order']
		dates = request.form['date']
		commonls.append(str(sidels))
		commonls.append(str(statels))
		commonls.append(str(symbol))
		commonls.append(str(client))
		commonls.append(str(size))
		commonls.append(str(qtydls))
		commonls.append(str(qtyols))
		commonls.append(str(orderidls))
		commonls.append(str(price_instr))
		commonls.append(str(exchange))
		commonls.append(str(dates))
		commonls.append(str(producttypels))
		commonls.append(str(askls))
		commonls.append(str(bidls))
		commonls.append(str(ltpls))
		newls.append(commonls)
		print(newls)

		return render_template('a.html',count = count -1,len = len(newls),commonls = commonls, newls = newls, symbol = symbol, symdescr = symdescr, size = size, price_instr = price_instr, limit = limit, client = client, client_descr = client_descr, exchange = exchange, account = account, counter_party = counter_party, day_order = day_order, dates = dates)
	return render_template('a.html')


@app.route('/save_entry',methods = ['GET', 'POST'])
def save_entry():
	outfile = open('data.txt','a')
	outfile.truncate(0)
	outfile.close()
	global dict_new
	dict_new = {}
	for i in range (0,len(newls)):
		dict_new = {
			'Side' : newls[i][0],
			'State': newls[i][1],
			'Symbol': newls[i][2],
			'Client': newls[i][3],
			'Size': newls[i][4],
		 	'QTY Done': newls[i][5],
			'QTY Open': newls[i][6],
			'OrderID': newls[i][7],
			'Price Instruction': newls[i][8],
			'Exchange': newls[i][9],
			'Dates': newls[i][10],
			'Product Types': newls[i][11],
			'AskLs': newls[i][12],
			'BidLs': newls[i][13],
			'LTPls': newls[i][14],
		}
		with open('data.txt', 'a') as outfile:
			json.dump(dict_new,outfile)
		jsonify(dict_new)
		getdata()
	return render_template('a.html',len = len(newls), newls = newls, fill_ls = fill_ls)

@app.route('/sell', methods = ['GET', 'POST'])
def sell():
	count  = 0
	if request.method == 'POST':
		print('index')
		sidels = 'S'
		commonls = []
		symbol = request.form['symbol']
		symdescr = request.form['symdescr']
		size = request.form['size']
		qtyols = size
		price_instr = request.form['price_instr']
		limit = request.form['limit']
		client = request.form['client']
		client_descr = request.form['client_descr']
		exchange = request.form['exchange']
		account  = request.form['account']
		orderidls = random.randint(100000,1000000)
		counter_party = request.form['counter_party']
		day_order = request.form['day_order']
		dates = request.form['date']
		commonls.append(str(sidels))
		commonls.append(str(statels))
		commonls.append(str(symbol))
		commonls.append(str(client))
		commonls.append(str(size))
		commonls.append(str(qtydls))
		commonls.append(str(qtyols))
		commonls.append(str(orderidls))
		commonls.append(str(price_instr))
		commonls.append(str(exchange))
		commonls.append(str(dates))
		commonls.append(str(producttypels))
		commonls.append(str(askls))
		commonls.append(str(bidls))
		commonls.append(str(ltpls))
		newls.append(commonls)
		print(newls)

		return render_template('a.html',len = len(newls),commonls = commonls, newls = newls, symbol = symbol, symdescr = symdescr, size = size, price_instr = price_instr, limit = limit, client = client, client_descr = client_descr, exchange = exchange, account = account, counter_party = counter_party, day_order = day_order, dates = dates)
	return render_template('a.html')

def modify(j):
	qtydls = data['QTY Approved']
	print(qtydls)
	newls[j][5] = qtydls
	newls[j][6] = str(int(newls[j][6]) - int(qtydls))
	d1 = {'QTY Done': qtydls}
	dict_new.update(d1)
	d2 = {'QTY Open': newls[j][6]}
	dict_new.update(d2)
	
	if(int(newls[j][6]) <= 0):
		fill_grid(newls,j)
	print(newls[j][6])
	print(newls)
	commonls = []
	commonls.append(str(newls[j][0]))
	commonls.append(str(statels))
	commonls.append(str(newls[j][1]))
	commonls.append(str(newls[j][2]))
	commonls.append(str(newls[j][3]))
	commonls.append(str(qtydls))
	commonls.append(str(newls[j][6]))
	commonls.append(str(temp_ID))
	commonls.append(str(newls[j][7]))
	commonls.append(str(newls[j][8]))
	commonls.append(str(newls[j][9]))
	commonls.append(str(producttypels))
	commonls.append(str(askls))
	commonls.append(str(bidls))
	commonls.append(str(ltpls))
	for new in newls:
		for common in new:
			print(common)
	outfile1 = open('data123.txt', 'a')
	outfile1.truncate(0)
	outfile1.close()
	return render_template('a.html', newls=newls,fill_ls = fill_ls)

def fill_grid(newls, j):
	fill_temp = []
	print(j)
	newls[j][1] = 'Filled'
	d3 = {'State' : 'Filled'}
	dict_new.update(d3)
	with open('data.txt', 'w') as outfile:
		json.dump(dict_new,outfile)
	fill_temp.append(newls[j][7])
	fill_temp.append(newls[j][5])
	fill_temp.append(newls[j][9])
	fill_temp.append(newls[j][10])
	fill_temp.append(price)
	fill_temp.append(str(random.randint(100000,100000000)))
	fill_ls.append(fill_temp)
	print(fill_temp)
	print(fill_ls)
	return render_template('a.html',newls = newls, fill_ls = fill_ls)
		
def getdata():
	global data,temp_ID
	if os.stat("data123.txt").st_size == 0:
		return render_template('a.html')
	with open('data123.txt') as f:
		data = json.load(f)
	temp_ID = data['OrderID']	
	for i in range (0,len(newls)):
		if temp_ID == newls[i][7]:
			j = i
			break
		else:
			continue
	return render_template('a.html',response = modify(j = i))

		

if __name__ == '__main__':
    app.run(debug=True)









